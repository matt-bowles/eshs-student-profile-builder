import React, { Component } from 'react'

import Paper from '@material-ui/core/Paper';

import { BackButton } from '..'

export default class TrendsPage extends Component {
  

  
    render() {
    return (
      <>

        <BackButton />

        <Paper style={{ margin: "auto", width: "60rem", height: "460px", border: "solid 2px black" }}>
            
        </Paper>
      </>
    )
  }
}
