import React, { useState, useEffect } from 'react';

import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';

import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';

import Skeleton from '@material-ui/lab/Skeleton';

import PeopleIcon from '@material-ui/icons/People';
import PersonIcon from '@material-ui/icons/Person';

import { Link } from 'react-router-dom';

import { BackButton } from '..';
import axios from 'axios';

export default function TrendsPage() {

const buttonStyles = { padding: "20px" }

const headingStyles = { marginBottom: "10px" }

  const [classList, setClassList] = useState([]);
  const [filteredClassList, setFilteredClassList] = useState([]);

  const [studentList, setStudentList] = useState([]);
  const [filteredStudentList, setFilteredStudentList] = useState([]);

  useEffect(() => {
    async function fetchClassList() {
      var data = await axios.get('/api/classes');
      setFilteredClassList(data.data);
    }

    async function fetchStudentList() {
      var data = await axios.get('/api/students');
      setFilteredStudentList(data.data);
    }

    fetchClassList();
    fetchStudentList();
  });

  return (
    <div>

      <BackButton />

      <Paper style={{ margin: "auto", width: "60rem", height: "460px", border: "solid 2px black" }}>


          <Grid container direction="row" justify="center" alignItems="center">

            <Grid container item direction="column" xs={6}>
              <Link to="/trends/classes" style={{ textDecoration: "none" }}>
                <Paper elevation={2} style={buttonStyles} style={{ margin: "18px", padding: "18px" }}>
                    <Typography variant="h4" style={headingStyles}>Class breakdowns <PeopleIcon /></Typography>
                    <Typography>View student traits on a class-by-class basis</Typography>

                    {filteredClassList.length === 0 ? (
                          <><br />
                            <br />
                            <Skeleton variant="rect" height={20} width={"75%"} />
                            <br />
                            <Skeleton variant="rect" height={20} width={"90%"} />
                            <br />
                            <Skeleton variant="rect" height={20} width={"85%"} />
                        </>
                    ) :
                    
                    <List>

                      </List>
                    
                    }

                </Paper>
              </Link>
            </Grid>

            <Grid container direction="column" item xs={6}>
              <Link to="/trends/students" style={{ textDecoration: "none" }}>
                <Paper elevation={2} style={buttonStyles} style={{ margin: "18px", padding: "18px" }}>
                    <Typography variant="h4" style={headingStyles}>Student breakdowns <PersonIcon /></Typography>
                    <Typography>Compare students' traits  semesters</Typography>
                </Paper>
              </Link>
            </Grid>

          </Grid>

      </Paper>
      
    </div>
  )
}
