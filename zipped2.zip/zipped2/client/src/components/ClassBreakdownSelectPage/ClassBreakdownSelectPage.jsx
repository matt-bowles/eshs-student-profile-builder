import React, { useState, useEffect } from 'react';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';


import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';


import { BackButton } from '../index';
import { Link } from 'react-router-dom';

import axios from 'axios';

export default function ClassBreakdownSelectPage() {

    const [classList, setClassList] = useState([]);

    useEffect( () => {
        async function fetchClassList() {
            // Fetch class list from API
            var {data} = await axios.get('/api/classes');
            setClassList(data);
          }
          fetchClassList();
    });

    const renderClassList = classList.map((classCode) =>
        <ListItem key={classCode}>
            <Link to={`/trends/classes/${classCode}`} style={{ textDecoration: "none" }}>
                <ListItemText primary={classCode} secondary={"XX students"} />
            </Link>
        </ListItem>
    );

    return (
        <>
            <BackButton />

            <Paper style={{ margin: "auto", width: "60rem", height: "460px", border: "solid 2px black" }}>
                <Typography variant={"h4"}><b>Classes</b></Typography>

                <List>
                    {classList.length > 0 && renderClassList}
                </List>
            </Paper>

        </>
    );
}
